  <!-- Footer -->
    <footer class="footer">
        © <?php echo date('Y').' '. $site_settings_row['site_name']; ?></span>.
    </footer>

    <!-- End Footer -->

    <!-- jQuery  -->
   
    <script src="<?php echo ADMIN_URL; ?>assets/js/bootstrap.bundle.min.js"></script>
    <script src="<?php echo ADMIN_URL; ?>assets/js/jquery.slimscroll.js"></script>
    <script src="<?php echo ADMIN_URL; ?>assets/js/waves.min.js"></script>


    <!-- App js -->
    <script src="<?php echo ADMIN_URL; ?>assets/js/app.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert.min.js"></script>
    <script src="<?php echo ADMIN_URL; ?>assets/js/sweetalert.js"></script>

</body>

</html>