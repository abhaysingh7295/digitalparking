<div class="text-center m-t-0 m-b-15">
       <h5 class="font-18 text-center"> Help and Support:- </h5>
       <p> <strong>Email :-</strong> <a href="mailto:support@thedigitalparking.com">support@thedigitalparking.com</a> </p>
       <p> <strong>Help-line:-</strong> <a href="tel:7410906906">+91-7410906906</a>  </p>
</div>