<?php include '../../config.php'; 

header('location:'.VENDOR_URL);